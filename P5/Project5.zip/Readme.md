# About the file

The report directory puts our report.
The code directory puts our code.
- ShoppingWithCoupon: This is our main code,you can run it yourself to check if it can work well.
- data:This is our code to create data,before you run our main code you should firstly run this code to create data file that provide data for main code.Otherwise,you can create a file name `data1.out` which contain the input data in a way that is given in PTA.

After you run the main code correctly you will find a `ans1.out` file , that's the result of the main code.