# Readme

- Dijkstra.cpp：存放main函数和测试代码主体
- dataConstructo.cpp：用于构造完全图测试数据，构造出的数据存放在testdata文件夹中
- testdata：存放测试数据。默认仅有https://www.diag.uniroma1.it/challenge9/download.shtml网站的7组数据，其余数据请自行用dataConstructor生成
- TestResult.xlsx：存放作者在本地测试的几组结果